<?php
/**
 * Plugin Name:       Login with Bondhumohal Network - India Ka Social Network - Social Login Plugin for Bondhumohal Network
 * Description:       Login and Register your users using Bondhumohal Api. Add social share button on your wordpress website.
 * Version:           1.0
 * Author:            senindiaonline
 * Author URI:        https://senindiaonline.in
 * Text Domain:       bondhumohal
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

/*
 * Plugin constants
 */
if(!defined('BM_URL'))
	define('BM_URL', plugin_dir_url( __FILE__ ));
if(!defined('BM_PATH'))
	define('BM_PATH', plugin_dir_path( __FILE__ ));

/*
 * Import the plugin classes
 */
include (BM_PATH . 'classes/bondhumohal.php');
include (BM_PATH . 'classes/bondhumohaladmin.php');

/*
 * Redirect after activation
 */
function bondhumohal_activation_redirect( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'admin.php?page=bondhumohal_login' ) ) );
    }
}
add_action( 'activated_plugin', 'bondhumohal_activation_redirect' );